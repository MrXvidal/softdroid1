package com.softdroid.puzzlev2;

public class DIALOG_LOGIN {
}
